#!/bin/bash
clear
echo "  ________________ __  ___           _      ____        __ "
echo " /_  __/ ___/__  //  |/  /_  _______(_)____/ __ )____  / /"
echo "  / /  \__ \ /_ </ /|_/ / / / / ___/ / ___/ __  / __ \/ __/"
echo " / /  ___/ /__/ / /  / / /_/ (__  ) / /__/ /_/ / /_/ / /_  "
echo "/_/  /____/____/_/  /_/\__,_/____/_/\___/_____/\____/\__/ "
echo

cd "$(dirname "$(readlink -f "${BASH_SOURCE[0]}")")"
cd system
java -Xms50m -Xmx50m -XX:+DisableAttachMechanism -XX:+IgnoreUnrecognizedVMOptions --illegal-access=permit --add-opens=java.base/java.lang=ALL-UNNAMED -jar TS3MusicBotLauncher.jar $*
cd ..
